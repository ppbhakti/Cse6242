# -*- coding: utf-8 -*-
"""
Created on Sat Feb 03 13:49:58 2018

@author: bhakt
"""

import csv
import json
import time
import tweepy


# You must use Python 2.7.x

# 1 point
def loadKeys(key_file):
    # TODO: put your keys and tokens in the keys.json file,
    #       then implement this method for loading access keys and token from keys.json
    # rtype: str <api_key>, str <api_secret>, str <token>, str <token_secret>

    # Load keys here and replace the empty strings in the return statement with those keys
    key=json.load(open(key_file))
    api_secret=key["api_secret"]
    api_key=key["api_key"]
    token=key["token"]
    token_secret=key["token_secret"]
    

    return api_key,api_secret,token,token_secret

# 4 points
def getPrimaryFriends(api, root_user, no_of_friends):
    # TODO: implement the method for fetching 'no_of_friends' primary friends of 'root_user'
    # rtype: list containing entries in the form of a tuple (root_user, friend)
    primary_friends = []
    # Add code here to populate primary_friends
    #source used=https://stackoverflow.com/questions/17455107/the-best-way-to-get-a-list-of-followers-in-python-with-tweepy
    friend_firstlevel=[]
    #ct=no_of_friends
    friend_firstlevel=api.friends(root_user,count=no_of_friends)
    for friends in friend_firstlevel:
        primary_friends.append((root_user,str(friends.screen_name)))
    print primary_friends
        
    return primary_friends

# 4 points
def getNextLevelFriends(api, users_list, no_of_friends):
    # TODO: implement the method for fetching 'no_of_friends' friends for each user in users_list
    # rtype: list containing entries in the form of a tuple (user, friend)
    next_level_friends = []
    # Add code here to populate next_level_friends
    for prim_friend,sec_friend in users_list:#in the list the first entry is polochau and second entry is his first 20 friends so i am using again api.friends to get another 20 freinds of each of polo chau's 20 friends
        friend_list=api.friends(sec_friend,count=no_of_friends)
        for friend in friend_list:
            next_level_friends.append((sec_friend,str(friend.screen_name)))
        print next_level_friends
    return next_level_friends

# 4 points
def getNextLevelFollowers(api, users_list, no_of_followers):
    # TODO: implement the method for fetching 'no_of_followers' followers for each user in users_list
    # rtype: list containing entries in the form of a tuple (follower, user)    
    next_level_followers = []
    # Add code here to populate next_level_followers
    for prim_friend, sec_friend in users_list: # first selecting the first 20 followers of each of the secondary friend selected
        followers = api.followers(sec_friend, count=no_of_followers)
        
        for follower in followers: #appending that list of followers in the array next_level_followers with the required tuple
            next_level_followers.append((str(follower.screen_name), sec_friend))
    print " next_level_followers"
    print  next_level_followers
    return next_level_followers

# 3 points
def GatherAllEdges(api, root_user, no_of_neighbours):
    # TODO:  implement this method for calling the methods getPrimaryFriends, getNextLevelFriends
    #        and getNextLevelFollowers. Use no_of_neighbours to specify the no_of_friends/no_of_followers parameter.
    #        NOT using the no_of_neighbours parameter may cause the autograder to FAIL.
    #        Accumulate the return values from all these methods.
    # rtype: list containing entries in the form of a tuple (Source, Target). Refer to the "Note(s)" in the 
    #        Question doc to know what Source node and Target node of an edge is in the case of Followers and Friends. 
    all_edges = [] 
    #Add code here to populate all_edges
    primary_friends = getPrimaryFriends(api, root_user, no_of_neighbours)
    second_friends = getNextLevelFriends(api, primary_friends, no_of_neighbours)
    next_level_followers = getNextLevelFollowers(api,primary_friends, no_of_neighbours)
    all_edges=primary_friends+second_friends+next_level_followers
    return all_edges


# 2 points
    #the below materials were found on the python website listed https://docs.python.org/2/library/csv.html
def writeToFile(data, output_file):
    with open(output_file,'wb') as csv_file:
        csv_write=csv.writer(csv_file,quoting=csv.QUOTE_ALL)
        for row in data:
            csv_write.writerow(row)
    pass
        
            
    




"""
NOTE ON GRADING:

We will import the above functions
and use testSubmission() as below
to automatically grade your code.

You may modify testSubmission()
for your testing purposes
but it will not be graded.

It is highly recommended that
you DO NOT put any code outside testSubmission()
as it will break the auto-grader.

Note that your code should work as expected
for any value of ROOT_USER.
"""

def testSubmission():
    KEY_FILE = 'keys.json'
    OUTPUT_FILE_GRAPH = 'graph.csv'
    NO_OF_NEIGHBOURS = 20
    ROOT_USER = 'PoloChau'

    api_key, api_secret, token, token_secret = loadKeys(KEY_FILE)

    auth = tweepy.OAuthHandler(api_key, api_secret)
    auth.set_access_token(token, token_secret)
    api = tweepy.API(auth,wait_on_rate_limit= True)

    edges = GatherAllEdges(api, ROOT_USER, NO_OF_NEIGHBOURS)

    writeToFile(edges, OUTPUT_FILE_GRAPH)
    

if __name__ == '__main__':
    testSubmission()

