$(function(){
	$('button').click(function(){
		var username= $('Username').val();
		var passwo = $('Password').val();
		$.ajax({
			url: '/signup',data: $('form').serialize(),success: function(response){console.log(response)
			},
			
			
		});
	});
});
